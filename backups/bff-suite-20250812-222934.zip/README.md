# bff-suite (Trey)

- `/trey-suite/index.html` — studio links
- `/trey-suite/bff-memory.html` — paste Supabase URL + anon, connect, save/refresh
- `/trey-suite/trey-assistant-widget.html` — floating widget; lazy-loads Supabase; blocks keys/tokens

GitHub Pages deploys via workflow in `.github/workflows/pages.yml` and serves `trey-suite/` as the site root.
