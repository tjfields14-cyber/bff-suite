﻿import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
type FileInput={path:string;content?:string;content_base64?:string};
type Payload={files:FileInput[];message?:string;branch?:string;author?:{name:string;email:string}|null;pr?:boolean;pr_title?:string;pr_body?:string;feature_prefix?:string};
const GH={token:Deno.env.get("GITHUB_TOKEN")!,repo:Deno.env.get("REPO_FULL_NAME")!,base:Deno.env.get("REPO_BRANCH")??"main"};
const SUPA={url:Deno.env.get("SUPABASE_URL")!,service:Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!};
async function gh(p:string,i:RequestInit={}){const r=await fetch(`https://api.github.com${p}`,{...i,headers:{"Authorization":`Bearer ${GH.token}`,"User-Agent":"chapterhouse-sync","Content-Type":"application/json",...(i.headers||{})}});const t=await r.text();let j=null;try{j=JSON.parse(t)}catch{};return{ok:r.ok,status:r.status,json:j,text:t}}
async function log(row:Record<string,unknown>){await fetch(`${SUPA.url}/rest/v1/file_version_log`,{method:"POST",headers:{"apikey":SUPA.service,"Authorization":`Bearer ${SUPA.service}`,"Content-Type":"application/json","Prefer":"return=representation"},body:JSON.stringify([row])}).catch(()=>{})}
function b64(s:string){const b=new TextEncoder().encode(s);let x="";for(const i of b)x+=String.fromCharCode(i);return btoa(x)}
async function headSha(ref:string){const r=await gh(`/repos/${GH.repo}/git/ref/heads/${encodeURIComponent(ref)}`);if(!r.ok)throw new Error(r.text);return r.json.object.sha}
async function makeBranch(sha:string,name:string){const r=await gh(`/repos/${GH.repo}/git/refs`,{method:"POST",body:JSON.stringify({ref:`refs/heads/${name}`,sha})});if(!r.ok)throw new Error(r.text)}
async function fileSha(path:string,branch:string){const r=await gh(`/repos/${GH.repo}/contents/${encodeURIComponent(path)}?ref=${encodeURIComponent(branch)}`);if(r.status===404)return null;if(!r.ok)throw new Error(r.text);return r.json.sha}
async function putFile(path:string,b64c:string,msg:string,branch:string,author?:{name:string;email:string}|null){const s=await fileSha(path,branch).catch(()=>null);const body:any={message:msg,content:b64c,branch};if(s)body.sha=s;if(author)body.committer=author;return gh(`/repos/${GH.repo}/contents/${encodeURIComponent(path)}`,{method:"PUT",body:JSON.stringify(body)})}
async function openPR(head:string,base:string,title:string,body?:string){const r=await gh(`/repos/${GH.repo}/pulls`,{method:"POST",body:JSON.stringify({title,head,base,body})});if(!r.ok)throw new Error(r.text);return r.json}
serve(async(req)=>{if(req.method!=="POST")return new Response("Use POST",{status:405});let p:Payload;try{p=await req.json()}catch{return new Response("Invalid JSON",{status:400})}
if(!p.files?.length)return new Response("payload.files required",{status:400});const base=p.branch||GH.base;const msg=p.message||`chore: sync ${p.files.length} file(s)`;const author=p.author??null;let branch=base;let prUrl:string|null=null;
try{if(p.pr){const sha=await headSha(base);branch=`${p.feature_prefix||"bff"}/${Date.now()}`;await makeBranch(sha,branch)}
const results:any[]=[];for(const f of p.files){const b64c=f.content_base64||(f.content?b64(f.content):null);if(!f.path||!b64c){results.push({path:f.path,ok:false,error:"path and content required"});continue}
const r=await putFile(f.path,b64c,msg,branch,author);await log({path:f.path,status:r.ok?"success":"error",gh_status:r.status,gh_sha:r.json?.content?.sha??null,commit_message:msg,error:r.ok?null:(r.json?.message||r.text?.slice(0,300))});results.push({path:f.path,ok:r.ok,status:r.status,sha:r.json?.content?.sha??null})}
if(p.pr){const pr=await openPR(branch,base,p.pr_title||msg,p.pr_body||"");prUrl=pr.html_url}
return new Response(JSON.stringify({ok:true,base,branch,pr:prUrl,results}),{headers:{"Content-Type":"application/json"}})}
catch(e){return new Response(JSON.stringify({ok:false,error:String(e)}),{status:500,headers:{"Content-Type":"application/json"}})}})
