// Auto-generated: Supabase config
window.BFF_SUPABASE = {
  "url": "https://oqfltvvbarstbzsuuwcn.supabase.co",
  "anon": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9xZmx0dnZiYXJzdGJ6c3V1d2NuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ4ODgxMjEsImV4cCI6MjA3MDQ2NDEyMX0.5pvtI2tY4LshylQt6VDyPjGWU7nqNbh3uWhvDZKdzeg"
};
