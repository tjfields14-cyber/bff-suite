﻿import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
const SUPABASE_URL=Deno.env.get("SUPABASE_URL")!;
const SERVICE=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SECRET=Deno.env.get("GH_WEBHOOK_SECRET");
async function hmac256(key:string,raw:Uint8Array){const k=await crypto.subtle.importKey("raw",new TextEncoder().encode(key),{name:"HMAC",hash:"SHA-256"},false,["sign"]);const sig=new Uint8Array(await crypto.subtle.sign("HMAC",k,raw));return "sha256="+Array.from(sig).map(b=>b.toString(16).padStart(2,"0")).join("")}
async function log(row:Record<string,unknown>){await fetch(`${SUPABASE_URL}/rest/v1/file_version_log`,{method:"POST",headers:{"apikey":SERVICE,"Authorization":`Bearer ${SERVICE}`,"Content-Type":"application/json","Prefer":"return=representation"},body:JSON.stringify([row])}).catch(()=>{})}
serve(async(req)=>{if(req.method!=="POST")return new Response("Use POST",{status:405});const raw=new Uint8Array(await req.arrayBuffer());if(SECRET){const given=req.headers.get("X-Hub-Signature-256")||"";const ours=await hmac256(SECRET,raw);if(given!==ours)return new Response("Invalid signature",{status:401})}
if((req.headers.get("X-GitHub-Event")||"")!=="push")return new Response("ok",{status:200});const body=JSON.parse(new TextDecoder().decode(raw));const head=body?.head_commit;const files=new Set<string>();
for(const c of (body?.commits||[])){for(const p of (c.added||[]))files.add(p);for(const p of (c.modified||[]))files.add(p);for(const p of (c.removed||[]))files.add(p)}
const msg=head?.message||body?.ref||"push";for(const path of files){await log({path,status:"success",gh_status:200,gh_sha:head?.id||null,commit_message:msg})}
return new Response(JSON.stringify({ok:true,counted:files.size}),{headers:{"Content-Type":"application/json"}})})
